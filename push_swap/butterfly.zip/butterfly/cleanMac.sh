
#!/bin/bash
yes y |	rm -rf ~/Library/Caches/
yes y | rm -rf ~/Library/42_cache
yes y | rm -rf ~/Library/Application\ Support/Slack/Service\ Worker/CacheStorage/
yes y | rm -rf ~/Library/Application\ Support/Slack/Cache/
yes y | rm -rf ~/Library/Application\ Support/Slack/Code\ Cache/