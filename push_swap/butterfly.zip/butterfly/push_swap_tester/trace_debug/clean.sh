rm -rf test_case.txt
rm -rf output.txt
