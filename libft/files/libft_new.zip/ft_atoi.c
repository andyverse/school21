#include "libft.h"

int ft_atoi(const char *nptr)
{
    int i;
    int sp;
    int res;
    int sign;
    int c;

    i = 0;
    c = 0;
    sign = 1;
    res = 0;
    while (nptr[i])
    {
        if ((nptr[i] >= '0' && nptr[i] <= '9') \
            || (nptr[i] == 32 && res == 0 && c == 0))
            res = res * 10 + (sp = (nptr[i] == 32) ? 0 : nptr[i] - 48);
        else if ((nptr[i] == '-') && (c++ == 0))
            sign = -1;
        else if ((nptr[i++] == '+') && (c++ == 0))
            continue ;
        else
            return (res * sign);
        i++;
    }
    return (res * sign);
}