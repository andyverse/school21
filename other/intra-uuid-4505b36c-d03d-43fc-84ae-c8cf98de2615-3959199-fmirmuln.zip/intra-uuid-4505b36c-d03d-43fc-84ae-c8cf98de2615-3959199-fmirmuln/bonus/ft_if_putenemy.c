/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_if_putenemy.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:53:52 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/06 19:53:54 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	ft_if_putenemy(t_game_map **map)
{
	if (BONUS == 1)
		ft_put_enemy(map);
}

void	ft_put_steps(t_render_v **vars, t_game_map **map)
{
	char	*go;

	if (BONUS)
	{
		go = ft_itoa((*map)->steps);
		mlx_string_put((*vars)->mlx, (*vars)->win, 10, 10, ORANGE, go);
		free(go);
	}
}
