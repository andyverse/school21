/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putint.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:54:42 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/06 19:54:44 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../libft.h"

static int	ft_numberlength(int n)
{
	unsigned int	o;
	int				l;

	l = 0;
	if (n < 0)
	{
		o = -n;
	}
	else
	{
		o = n;
	}
	while (o > 0)
	{
		o /= 10;
		l++;
	}
	return (l);
}

int	ft_putint(int n)
{
	ft_putnbr_fd(n, 1);
	if (n == 0)
		return (1);
	if (n < 0)
		return (ft_numberlength(n) + 1);
	return (ft_numberlength(n));
}
