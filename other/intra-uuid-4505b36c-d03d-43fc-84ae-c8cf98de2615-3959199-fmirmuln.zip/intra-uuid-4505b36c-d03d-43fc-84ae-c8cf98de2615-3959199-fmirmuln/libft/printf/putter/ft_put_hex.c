/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_hex.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:54:30 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/06 19:54:33 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../libft.h"

int	ft_put_hex(unsigned long long p, int u)
{
	if (p == 0)
		return (ft_putstr("0"));
	if (u == 1)
		return (ft_dec_to_hex(p, 0, 1));
	return (ft_dec_to_hex(p, 1, 1));
}
