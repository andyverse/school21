/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putuint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:54:56 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/06 19:54:59 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../libft.h"

static int	ft_numberlength(unsigned int n)
{
	unsigned int	o;
	unsigned int	l;

	o = n;
	l = 0;
	if (n < 0)
		o = -o;
	while (o > 0)
	{
		o /= 10;
		l++;
	}
	return (l);
}

int	ft_putuint(unsigned int n)
{
	ft_putunbr_fd(n, 1);
	if (n == 0)
		return (1);
	return (ft_numberlength(n));
}
