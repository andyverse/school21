/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:47:17 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/06 19:47:19 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	unsigned int	lenc;
	unsigned char	d;
	unsigned char	*t;

	lenc = 0;
	lenc = 0;
	d = (unsigned char)c;
	t = (unsigned char *)b;
	while (len > lenc)
	{
		t[lenc] = d;
		lenc++;
	}
	return (b);
}
