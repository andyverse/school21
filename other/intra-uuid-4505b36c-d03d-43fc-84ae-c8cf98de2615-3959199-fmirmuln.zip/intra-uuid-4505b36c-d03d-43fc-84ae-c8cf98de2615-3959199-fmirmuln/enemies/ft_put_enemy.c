/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_enemy.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:54:15 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/07 23:38:20 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	ft_put_enemy(t_game_map **map)
{
	static int	enemypos[2];
	static int	enemyset = 0;

	while (enemyset == 0)
	{
		enemypos[1] = ((ft_ps_random() + 1) % (*map)->map_height);
		enemypos[0] = ((ft_ps_random() + 1) % (*map)->map_length);
		if (!(enemypos[0] == ((*map)->player_position_x / TILE_WIDTH)))
			enemyset++;
		if (!(enemypos[1] == ((*map)->player_position_y / TILE_WIDTH)))
			enemyset++;
		(*map)->enemypos = enemypos;
		(*map)->enemyset = 1;
	}
	(*map)->enemypos = enemypos;
}
