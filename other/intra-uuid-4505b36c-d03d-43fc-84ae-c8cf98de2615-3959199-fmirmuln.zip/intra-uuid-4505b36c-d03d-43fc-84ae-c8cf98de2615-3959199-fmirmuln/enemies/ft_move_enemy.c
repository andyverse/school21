/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_move_enemy.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:54:05 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/07 23:43:33 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

static int	is_valid_y(int change, t_game_map **map)
{
	if (change < 0)
		return (0);
	if (change >= (*map)->map_height)
		return (0);
	return (1);
}

static int	is_valid_x(int change, t_game_map **map)
{
	if (change < 0)
		return (0);
	if (change >= (*map)->map_length)
		return (0);
	return (1);
}

void	ft_move_enemy(t_game_map **map)
{
	int	change;
	int	dir;
	int	ho;

	change = (ft_ps_random() + (*map)->steps) % 10;
	dir = ft_ps_random() % 2;
	ho = (*map)->enemypos[0];
	if (dir == 1)
		ho = (*map)->enemypos[1];
	if (change > 4)
		ho = ho + 1;
	else
		ho = ho - 1;
	if (dir == 1 && is_valid_y(ho, map))
		(*map)->enemypos[1] = ho;
	else if (dir == 0 && is_valid_x(ho, map))
		(*map)->enemypos[0] = ho;
}
