/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_character.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 23:19:21 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/07 23:19:26 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	ft_marvin_img(t_render_v **vars, t_game_map **map)
{
	char		*marvin;
	static void	*img;
	int			pos[2];

	marvin = "./assets/sprite_0.xpm";
	if (!img)
		img = mlx_xpm_file_to_image((*vars)->mlx, marvin, &pos[0], &pos[1]);
	(*map)->marvin = img;
}

void	ft_marvin2_img(t_render_v **vars, t_game_map **map)
{
	char		*marvin;
	static void	*img;
	int			pos[2];

	marvin = "./assets/sprite_1.xpm";
	if (!img)
		img = mlx_xpm_file_to_image((*vars)->mlx, marvin, &pos[0], &pos[1]);
	(*map)->marvin = img;
}

void	ft_marvin3_img(t_render_v **vars, t_game_map **map)
{
	char		*marvin;
	static void	*img;
	int			pos[2];

	marvin = "./assets/sprite_2.xpm";
	if (!img)
		img = mlx_xpm_file_to_image((*vars)->mlx, marvin, &pos[0], &pos[1]);
	(*map)->marvin = img;
}

void	ft_marvin4_img(t_render_v **vars, t_game_map **map)
{
	char		*marvin;
	static void	*img;
	int			pos[2];

	marvin = "./assets/sprite_3.xpm";
	if (!img)
		img = mlx_xpm_file_to_image((*vars)->mlx, marvin, &pos[0], &pos[1]);
	(*map)->marvin = img;
}
