/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_control_player.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 23:19:31 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/07 23:19:34 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

static t_game_map	*ft_check_tile(t_game_map *game_map)
{
	int	x;
	int	y;

	y = game_map->player_position_y / TILE_WIDTH;
	x = game_map->player_position_x / TILE_WIDTH;
	if (game_map->map_data[y][x] == 'C')
	{
		game_map->map_data[y][x] = '0';
		game_map->game_score++;
		ft_ps_random();
	}
	return (game_map);
}

t_game_map	*ft_control_player(int keycode, t_game_map *inj_game_map)
{
	static t_game_map	*game_map;
	static int			game_end = 0;

	ft_ps_random();
	if (game_map && (game_end == 0))
	{
		game_map = ft_keycode_action(game_map, keycode);
		game_map = ft_check_tile(game_map);
	}
	else if (inj_game_map && (game_end == 0))
	{
		game_map = inj_game_map;
		if (inj_game_map->game_over)
			game_end = 1;
		else
			ft_find_player(game_map, &game_map->player_position_x,
				&game_map->player_position_y);
	}
	return (game_map);
}
