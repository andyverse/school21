/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_animate.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fmirmuln <fmirmuln@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/06 19:53:36 by fmirmuln          #+#    #+#             */
/*   Updated: 2022/03/07 23:31:44 by fmirmuln         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

static void	state1(t_game_map **m, t_render_v **v)
{
	ft_marvin_img(v, m);
}

static void	state2(t_game_map **m, t_render_v **v)
{
	ft_marvin2_img(v, m);
}

static void	state3(t_game_map **m, t_render_v **v)
{
	ft_marvin3_img(v, m);
}

static void	state4(t_game_map **m, t_render_v **v)
{
	ft_marvin4_img(v, m);
}

int	ft_animate(t_game_map **m, t_render_v **v)
{
	static int			loop = 0;
	static t_render_v	**vars;

	if (BONUS)
	{
		if (v)
			vars = v;
		loop++;
		if (loop == 0 && (vars && m))
			state1(m, vars);
		if (loop == 1 && (vars && m))
			state2(m, vars);
		if (loop == 2 && (vars && m))
			state3(m, vars);
		if (loop == 3 && (vars && m))
		{
			state4(m, vars);
			loop = 0;
		}	
	}
	return (1);
}
